<div class="mt-20 flex flex-col items-center justify-center pb-20">
	<h1 class="text-4xl font-bold">Congratulations</h1>
	<p class="mt-5">
		The first time a person tries drugs or alcohol, it’s often out of curiosity. Maybe they heard
		about the drug from a friend or are just curious about the effects of the drug. Alone,
		experimentation doesn’t appear abusive, but even a single episode of experimentation can result
		in harm to oneself or others. For some people, drug use stops here, but for others, it’s only
		the start of a lifelong substance abuse disorder and the struggle to stay sober
	</p>
	<div class="aspect-video w-full">
		<iframe
			class="mt-10"
			title="motivation"
			width="100%"
			height="100%"
			src="https://www.youtube.com/embed/E1mSLfJF83s"
		>
		</iframe>
	</div>
</div>
