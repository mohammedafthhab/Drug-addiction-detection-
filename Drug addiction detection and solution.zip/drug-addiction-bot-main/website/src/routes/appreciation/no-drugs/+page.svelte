<div class="mt-20 flex flex-col items-center justify-center pb-20">
	<h1 class="text-4xl font-bold">Congratulations</h1>
	<div class="aspect-video w-full">
		<iframe
			class="mt-10"
			title="motivation"
			width="100%"
			height="100%"
			src="https://www.youtube.com/embed/CSKKjKHBKrg"
		>
		</iframe>
	</div>
</div>
